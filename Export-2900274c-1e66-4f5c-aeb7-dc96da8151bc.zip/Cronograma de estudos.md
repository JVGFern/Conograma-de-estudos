# Cronograma de estudos

## 📅 Cronograma semanal

[Meu cronograma semanal](https://www.notion.so/6a7b7c21a04e4a10b82a6086c7c09711)

## 📅 Cronograma diário

[Calendário de estudos](https://www.notion.so/4adf2d615c5f4129b81c54c66054bcf9)